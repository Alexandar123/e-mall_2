<?php
/**
 * Copyright © SmallStripes. All rights reserved.
 * See COPYING.txt for license details.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'SmallStripes_ShippingRestrictions',
    __DIR__
);
