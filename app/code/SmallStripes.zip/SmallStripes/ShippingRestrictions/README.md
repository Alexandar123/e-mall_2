# Shipping Restrictions
Magento 2 shipping restrictions module
